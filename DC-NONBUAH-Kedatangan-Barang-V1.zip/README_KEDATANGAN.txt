DC NONBUAH - Menu Kedatangan Barang (baru)

Yang ditambahkan:
1. Menu sidebar "Kedatangan Barang" (ikon truck) di section Operasional.
2. Halaman form:
   - Tanggal (otomatis hari ini, bisa diubah)
   - Vendor (opsional, dropdown dari Master Vendor)
   - Nama Produk (cari seperti Retur, autocomplete)
   - Qty
   - Satuan (select + chips: RENTENG / PCS / BALL / DUS / BOX / PACK)
   - Catatan (opsional)
3. Semua field TIDAK wajib. Minimal isi nama atau qty.
4. Tidak ada No. Surat, tidak ada Barcode wajib.
5. Daftar kedatangan di bawah form (bisa hapus per item, kosongkan semua, export Excel).
6. Data disimpan di localStorage + dicoba ke koleksi Firestore "kedatangan".
7. Role yang bisa akses: sama seperti Retur Barang (Anggota Tim ke atas).

Cara pakai:
- Login → klik menu Kedatangan Barang
- Isi form → Tambah ke Daftar
- Export bila perlu
